#include <iostream>
#include <cstring>
#include <stdlib.h>

// Buffer Overflow Vulnerability - No size check
void buffer_overflow_vulnerable() {
    char buffer[10];
    char input[] = "This is a very long string that will definitely cause a buffer overflow";
    strcpy(buffer, input);  // Clear buffer overflow vulnerability
}

// Command Injection Vulnerability - No input validation
void command_injection_vulnerable(const char* user_input) {
    char command[256];
    sprintf(command, "ls %s", user_input);  // Clear command injection vulnerability
    system(command);  // Execute without validation
}

// Memory Leak - No free
void memory_leak_vulnerable() {
    int* ptr = (int*)malloc(sizeof(int));
    *ptr = 42;
    // Memory leak: no free(ptr)
}

// Use After Free
void use_after_free_vulnerable() {
    char* ptr = (char*)malloc(100);
    strcpy(ptr, "Hello World");
    free(ptr);
    printf("%s\n", ptr);  // Use after free
}

int main() {
    // Test buffer overflow
    buffer_overflow_vulnerable();
    
    // Test command injection
    const char* malicious_input = "../; rm -rf *";  // Malicious input
    command_injection_vulnerable(malicious_input);
    
    // Test memory leak
    memory_leak_vulnerable();
    
    // Test use after free
    use_after_free_vulnerable();
    
    return 0;
} 