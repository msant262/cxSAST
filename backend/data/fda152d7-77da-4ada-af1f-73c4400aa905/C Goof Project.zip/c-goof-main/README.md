# c-goof
[![FOSSA Status](https://app.fossa.com/api/projects/git%2Bgithub.com%2Fpilvikala%2Fc-goof.svg?type=shield)](https://app.fossa.com/projects/git%2Bgithub.com%2Fpilvikala%2Fc-goof?ref=badge_shield)

Vulnerable C++ project

## License
[![FOSSA Status](https://app.fossa.com/api/projects/git%2Bgithub.com%2Fpilvikala%2Fc-goof.svg?type=large)](https://app.fossa.com/projects/git%2Bgithub.com%2Fpilvikala%2Fc-goof?ref=badge_large)
=======
Dependencies are in `vendor`. Clone this project, and run `snyk test --unmanaged` from the project folder. To import the results in Snyk App, run `snyk monitor --unmanaged`.
